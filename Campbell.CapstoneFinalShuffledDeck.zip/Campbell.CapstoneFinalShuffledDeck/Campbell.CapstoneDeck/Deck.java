public class Deck
{
	private String[] cards;

	public Deck()
	{
		cards = new String[52];
		String[] ranks = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king" };
		String[] suits = { "clubs", "diamonds", "hearts", "spades" };

		int k = 0;
		for (int s = 0; s < suits.length; s++)
		{
			for (int r = 0; r < ranks.length; r++)
			{
				cards[k++] = ranks[r] + " of " + suits[s];
			}
		}
	}

	public String[] getCards()
	{
		return cards;
	}
	public static void main(String[] args)
	{
		Deck deck = new Deck();
		for (String card : deck.getCards()) {
			System.out.println(card);
		}
	}
}