public class EntryPoint
{
	public static void main(String[] args)
	{
		Deck deck = new Deck();           // Create a fresh deck
		Shuffler shuffler = new Shuffler(deck); // Shuffle the deck
		shuffler.displayDeck();           // Display the shuffled cards
	}
}
