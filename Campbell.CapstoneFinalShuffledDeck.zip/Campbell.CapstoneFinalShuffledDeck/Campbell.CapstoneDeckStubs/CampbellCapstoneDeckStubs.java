public class CampbellCapstoneDeckStubs {// Constructor
   
    public CampbellCapstoneDeckStubs() {
        //This will initialize and create the deck.
    }

       // This will create an array sized to hold all cards.
       public String[] createArrayForCards(int rankLength, int suitLength) {
          // This will return a String array of size rankLength * suitLength.
        return null;
       }
   
       // This will add ranks to the cards.
       public String[] addRankToEachCard(String[] cards, String[] ranks) {
           //This will assign a rank to each card.
        return null;
       }
   
       // This will add suits to the cards.
       public String[] addSuitToEachCard(String[] cards, String[] suits) {
           //This will assign a suit. 
        return null;
       }
   
       // This will display the full deck
       public void displayDeckOfCards(String[] cards) {
       }
}