import java.util.Random;

public class Shuffle {

    // This method will take the deck and return a new shuffled deck
    public String[] shuffleTheDeck(String[] cards) {
        // This will randomly select cards and place them into a new array
        return null;
    }

    // This method will create an empty array the same length as the original deck
    public String[] createArrayForShuffledDeck(String[] cards) {
        // This will return an empty array for shuffled cards
        return null;
    }

    // This method will generate a random number used to pick a card index
    public int obtainRandomNumber(int numberOfCards) {
        // This will return a random number between 0 and numberOfCards - 1
        return 0;
    }
}