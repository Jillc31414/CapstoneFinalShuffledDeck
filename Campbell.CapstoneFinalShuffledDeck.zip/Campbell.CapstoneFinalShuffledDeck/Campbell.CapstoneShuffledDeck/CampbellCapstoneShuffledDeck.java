import java.util.Random;

public class CampbellCapstoneShuffledDeck {

    public CampbellCapstoneShuffledDeck() {// constructor
        // initialize the ranks and the suits
        String[] suits = {"clubs", "diamonds", "hearts", "spades"};
        String[] ranks = {"ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king"};
        String[] cards;
        String[] shuffledCards;

        // create the cards array
        // make the cards array exactly
        cards = createArrayForCards(ranks.length, suits.length);

        // add rank to each card
        cards = addRankToEachCard(cards, ranks);

        // add suit to each card
        cards = addSuitToEachCard(cards, suits);

        // display the original deck
        displayDeckOfCards(cards, "\n\nthe deck looks like:");

        // shuffle cards
        shuffledCards = shuffleTheDeck(cards);

        // display the shuffled cards
        displayDeckOfCards(shuffledCards, "\n\nthe shuffled deck looks like:");
    }

    public String[] addSuitToEachCard(String[] cards, String[] suits) {
        System.out.println("\nsuits");

        for (int n = 0; n < cards.length; n++) {
            //"\" means integer division
            System.out.print(n + " integer division 13 = " + n / 13 + "\t");

            cards[n] += " of " + suits[n / (cards.length / suits.length)];
        }

        return cards;
    }

    public String[] addRankToEachCard(String[] cards, String[] ranks) {
        
        for (int n = 0; n < cards.length; n++) {
            System.out.println(n + " mod 13 = " + n % ranks.length + "\t");
            cards[n] = ranks[n % ranks.length];
            System.out.println("cards[" + n + "] = " + cards[n]);
        }
        return cards;
    }

    public String[] createArrayForCards(int rankLength, int suitLength) {
       
        return new String[rankLength * suitLength];
    }

    public void displayDeckOfCards(String[] cards, String message) {
        String outputString = message + "\n";
        for (int n = 0; n < cards.length; n++) {
            if (n % 13 == 0) {
                outputString += "\n";
            }
            outputString += cards[n] + ", ";
        }
        outputString += "\n";
        System.out.println(outputString);
    }

    public String[] shuffleTheDeck(String[] cards) {
        String[] shuffledDeck;
        int randomValue;
        int shuffledDeckElementNumber = 0;

        shuffledDeck = createArrayForShuffledDeck(cards);

        for (int elementNumber = 0; elementNumber < cards.length; elementNumber++) {
            randomValue = obtainRandomNumber(cards.length);

            while (cards[randomValue].equals("-1")) {
                randomValue++;
                if (randomValue == 52) {
                    randomValue = 0;
                }
            }

            shuffledDeck[shuffledDeckElementNumber] = cards[randomValue];
            shuffledDeckElementNumber++;
            cards[randomValue] = "-1";
        }

        return shuffledDeck;
    }

    public int obtainRandomNumber(int numberOfCards) {
        Random rand = new Random();
        return rand.nextInt(numberOfCards);
    }

    public String[] createArrayForShuffledDeck(String[] deck) {
        return new String[deck.length];
    }

    public static void main(String[] args) {
        new CampbellCapstoneShuffledDeck();
    }
}