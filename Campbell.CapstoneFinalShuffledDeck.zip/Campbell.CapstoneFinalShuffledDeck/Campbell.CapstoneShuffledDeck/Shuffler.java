import java.util.Random;

public class Shuffler
{
	private String[] shuffledDeck;

	public Shuffler(Deck deck)
	{
		String[] original = deck.getCards();
		shuffledDeck = new String[original.length];

		boolean[] used = new boolean[original.length];
		Random random = new Random();
		int n = 0;

		while (n < shuffledDeck.length)
		{
			int index = random.nextInt(original.length);
			if (!used[index])
			{
				shuffledDeck[n++] = original[index];
				used[index] = true;
			}
		}
	}

	public void displayDeck()
	{
		for (String card : shuffledDeck)
		{
			System.out.println(card);
		}
	}
}
